In your C programs you need only to include snap7.h.

In your c++ program you also need to add snap7.cpp to the project.

In both cases, only in Windows, you need to add snap7.lib to the linker lib references (use the correct release in accord to your platform model 32 or 64 bit).