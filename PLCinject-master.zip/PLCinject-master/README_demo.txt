This demoprogram activates each digital output (Q136.0-Q137.7) sequentially.

!!! Please make sure that no actuators are attached to these outputs to prevent any harm !!!