## Continuous Reading

This example just uses a while loop, to keep reading a tag.

Run [test-03.py](../python_code/test-03.py) to see how this works.