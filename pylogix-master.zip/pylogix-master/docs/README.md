## Documentation Contents

- [Starter Guide](./guides/Starter-Guide.md)
- [Continuous Reading](./guides/Continuous-Reading.md)
- [Working with Files](./guides/Working-With-Files.md)
- [Working with LogFiles](./guides/Working-With-LogFiles.md)
- [API](Documentation.md)
- [Contributing](Contributing.md) TODO
- [Unit testing](../tests/README.md)