Contributing
============

.. mdinclude:: ../CONTRIBUTING.md