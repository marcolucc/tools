/***************************************************************************
 *  Copyright (C) 2006                                                     *
 *  Author : Stephane LEICHT    stephane.leicht@gmail.com                  *
 *                                                                         *
 *  This program is free software: you can redistribute it and/or modify   *
 *  it under the terms of the GNU General Public License as published by   * 
 *  the Free Software Foundation, either version 3 of the License, or      *
 *  (at your option) any later version.                                    *
 *                                                                         *
 *  This program is distributed in the hope that it will be useful,        * 
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of         *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the          *
 *  GNU General Public License for more details.                           *
 *                                                                         *
 *  You should have received a copy of the GNU General Public License      *
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.  *
 ***************************************************************************/
float Valeurs[]={1,2,4,5,10};


//GetSpan(Vmin,Vmax,Interval,Origine,10,15,Valeurs,sizeof(Valeurs))

/*int main(int argc, char *argv[])
{ float min=0,max=100;
  float Interval=0,Origine=0;
  int nbre=GetSpan(min,max,&Interval,&Origine);
  printf("%f -> %f = %d * %f + %f",min,max,nbre,Interval,Origine);
  return 0;
}*/
